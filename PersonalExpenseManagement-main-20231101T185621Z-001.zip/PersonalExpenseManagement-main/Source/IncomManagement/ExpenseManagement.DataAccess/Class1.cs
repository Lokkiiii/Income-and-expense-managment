﻿namespace ExpenseManagement.DataAccess
{
    public class Class1
    {

    }
}