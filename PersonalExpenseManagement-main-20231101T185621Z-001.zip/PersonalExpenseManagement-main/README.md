# PersonalExpenseManagement
Personal Expense management is the process of  saving, investing, spending, or otherwise overseeing the capital usage of an individual.

The Application consists of the following functions:

# 1.Income Management:
	 Income Management field helps to keep an accurate record of the money inflow. The user is going 
	 to provide the data from where he/she is receiving the amount as an income of source in the income
	 field.
   
# 2.Expense Management:
	Expense Management field helps to keep an accurate record of the money outflow. An expense management
	is that which simplifies the users expense reimbursement process by automating much of it.The software
	reduces the need for paper, lowers the amount of time spent handling expenses and minimizes errors.
  
# 3.List of Income and Expenses:
	This field provides the user the list of income and expenses done from and to a particular date.
